public interface HighLevelDisplay {

    public void clear();

    public void addRow(String str);

    public void deleteRow(int row);

}
